<?php
/**
 * @package		jVArcade
 * @version		2.13
 * @date		2016-02-18
 * @copyright		Copyright (C) 2007 - 2014 jVitals Digital Technologies Inc. All rights reserved.
 * @license		http://www.gnu.org/copyleft/gpl.html GNU/GPLv3 or later
 * @link		http://jvitals.com
 */



// no direct access
defined('_JEXEC') or die;

?>

		<div class="pu_bookmarks">
		<?php if ($this->config->bookmarks == 1) : ?>
			<!-- AddToAny BEGIN --> 
				<a class="a2a_dd" href="https://www.addtoany.com/share_save">
						<img src="//static.addtoany.com/buttons/share_save_171_16.png" width="171" height="16" border="0" alt="Share"/>
				</a> 
				<script type="text/javascript" src="//static.addtoany.com/menu/page.js"></script> 
			<!-- AddToAny END -->
		<?php endif;?>
		</div>
	